<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Login</title>
</head>
<body>
<div class="login-box">
  <p>Login</p>
  <form action="login.php" method="post">
    <div class="user-box">
      <input class="int" required="" id="email" name="email" type="email">
      <label>Email</label>
    </div>
    <div class="user-box">
      <input class="int" required="" id="password" name="password" type="password">
      <label>Password</label>
    </div>
    <input type="submit" value="Login">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
    </input>
  </form>
  <br>
  <p>Não tem uma conta? <a href="cadastro.php" class="a2">Cadastro</a></p>
</div>
    
</body>
</html>
<?php
// Configurações do banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$database = "tcc_va";
$port = 3306;

// Conexão com o banco de dados
$conn = new mysqli($servername, $username, $password, $database, $port);

// Verifica conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Verifica se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Consulta o banco de dados para verificar o login
    $sql = "SELECT * FROM usuarios WHERE email='$email' AND password ='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Usuário encontrado
        $row = $result->fetch_assoc();
        if ($row["email"] == 'adm@gmail.com' && $row["password"] == '1234') {
            // Redireciona para a página de administração
            header("Location: index_adm.php");
        } else {
            // Redireciona para a página de usuários comuns
            header("Location: index_usuario.php");
        }
    } else {
        // Caso contrário, exibe uma mensagem de erro
        echo "Email ou senha incorretos.";
    }
}

$conn->close();
?>
