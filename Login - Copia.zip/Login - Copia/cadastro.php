<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Usuário</title>
</head>
<body>
    <h2>Cadastro de Usuário</h2>
    <form action="cadastro.php" method="post">
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br>
        <label for="password">Senha:</label><br>
        <input type="password" id="password" name="password" required><br>
        <label for="nome">Nome:</label><br>
        <input type="text" id="nome" name="nome" required><br><br>
        <input type="submit" value="Cadastrar">
    </form>
</body>
</html>
<?php
// Configurações do banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$database = "tcc_va";
$port = 3306;

// Conexão com o banco de dados
$conn = new mysqli($servername, $username, $password, $database, $port);

// Verifica conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Verifica se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];
    $nome = $_POST["nome"];

    // Insere os dados do novo usuário no banco de dados
    $sql = "INSERT INTO usuarios (email, password, nome) VALUES ('$email', '$password', '$nome')";

    if ($conn->query($sql) === TRUE) {
        echo "Usuário cadastrado com sucesso.";
        header("Location: index_usuario.php");
    } else {
        echo "Erro ao cadastrar usuário: " . $conn->error;
    }
}

$conn->close();
?>
