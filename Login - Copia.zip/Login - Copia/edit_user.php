
<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "tcc_va";
$port = 3306;

// Conexão com o banco de dados
$conn = new mysqli($servername, $username, $password, $database, $port);

// Verifica conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Verifica se o ID do usuário foi passado via GET
if(isset($_GET['id'])) {
    $user_id = $_GET['id'];

    // Consulta para selecionar os detalhes do usuário com base no ID
    $sql = "SELECT * FROM usuarios WHERE id=$user_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $email = $row["email"];
        $password = $row["password"];
        $nome = $row["nome"];
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>
<body>
<?php
echo "<h2>Editar Usuário</h2>";
echo "<form action='update_user.php' method='post'>";
echo "<input type='hidden' name='id' value='$user_id'>";
echo "Email: <input type='email' name='email' value='$email'><br>";
echo "Senha: <input type='text' name='password' value='$password'><br>";
echo "Nome: <input type='text' name='nome' value='$nome'><br>";
echo "<input type='submit' value='Salvar'>";
echo "</form>";
} else {
echo "Usuário não encontrado.";
}
} else {
echo "ID do usuário não especificado.";
}

