
<?php
// Configurações do banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$database = "tcc_va";
$port = 3306;

// Conexão com o banco de dados
$conn = new mysqli($servername, $username, $password, $database, $port);

// Verifica conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>
    <body>
        <section>
<h2>Lista de contatos</h2>
        
        <?php
// Configurações do banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$database = "tcc_va";
$port = 3306;

// Conexão com o banco de dados
$conn = new mysqli($servername, $username, $password, $database, $port);

// Verifica conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Consulta para selecionar todos os usuários
$sql = "SELECT id, email, password, nome FROM usuarios";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Exibir cabeçalho da tabela
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Email</th><th>Senha</th><th>Nome</th></tr>";

    // Exibir dados de cada usuário
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row["id"]."</td>";
        echo "<td>".$row["email"]."</td>";
        echo "<td>".$row["password"]."</td>";
        echo "<td>".$row["nome"]."</td>";
        echo "<td><a href='edit_user.php?id=".$row["id"]."'>Editar</a></td>";
    echo "<td><a href='delete_user.php?id=".$row["id"]."'>Excluir</a></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Nenhum usuário encontrado.";
}

$conn->close();
?>

</section>
    </body>


</html>