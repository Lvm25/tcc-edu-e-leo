<?php
// Configurações do banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$database = "tcc_va";
$port = 3306;

// Conexão com o banco de dados
$conn = new mysqli($servername, $username, $password, $database, $port);

// Verifica conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Verifica se o ID do usuário foi passado via GET
if(isset($_GET['id'])) {
    $user_id = $_GET['id'];

    // Excluir pedidos associados ao usuário
    $sql_delete_pedidos = "DELETE FROM pedidos WHERE usuario_id=$user_id";

    if ($conn->query($sql_delete_pedidos) === TRUE) {
        // Excluir o usuário
        $sql_delete_user = "DELETE FROM usuarios WHERE id=$user_id";

        if ($conn->query($sql_delete_user) === TRUE) {
            echo "Usuário e pedidos associados excluídos com sucesso.";
        } else {
            echo "Erro ao excluir usuário: " . $conn->error;
        }
    } else {
        echo "Erro ao excluir pedidos associados: " . $conn->error;
    }
} else {
    echo "ID do usuário não especificado.";
}

$conn->close();
?>
